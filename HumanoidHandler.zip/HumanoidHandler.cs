using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Pathfinding;

public class HumanoidHandler : MonoBehaviour 
{
	public static List<HumanoidHandler> ListOfHumans = new List<HumanoidHandler>();
	public static List<HumanoidHandler> ListOfZombies = new List<HumanoidHandler>();
	
	/// <summary>
	/// Character attack using state--User defined, type of attack being used
	/// </summary>
	public enum StateCharacterAtkUsing { WeakAttack, MediumAttack, StrongAttack }
	
	
	/// <summary>
	/// Character attack behave state--User defined, stand until attacked or attack nearest
	/// </summary>
	public enum StateCharacterBehave { StandAndRun, Stand, AtkNearest }
	
	/// <summary>
	/// Character state--Zombie or Human.
	/// </summary>
	public enum StateCharacterType { Zombie, Human }
	
	/// <summary>
	/// Zombie type--The type the character is or will turn into if infected.
	/// </summary>
	public enum StateZombieType { Sneeky, Strong, Fast }
	/// <summary>
	/// Animation Atate->animation: Standing->standing, Walking->walking or shambling, 
	///           Running->running, Attacking-> hitting or shooting
	/// 
	/// NOTE: Standing, Walking, Running, and Attacking add HoldGun to respective animation
	/// </summary>
	public enum StateAnim { Standing, Walking, Running, Attacking }
	
	
		
	public static Texture2D FastTex;
	public static Texture2D SneakyTex;
	//public static Texture2D ToughTex;
	public static Texture2D HumanTex;
	//public static Texture2D MilitaryTex;
	
	/// State enum variables--The enum variables representing current states.
	
	public StateCharacterAtkUsing CurrUsingAttack;
	public StateCharacterBehave CurrBehavior;
	public StateCharacterType CurrCharacterType;
	public StateZombieType CurrZombType;
	public StateAnim CurrAnimation;
	
	public bool isSelected; //By the player, needed in AIPather.cs so all zombies aren't moved at once.
	
	
	/// <summary>
	/// isTargeting -> either targeting a walkToPoint or an enemy.
	/// If not targeting, the user is controling the zombie.
	/// </summary>
	public bool isTargeting;
	public bool isArmed;
	public int maxHealth;
	public int currHealth;
	public int maxResistance;// for infecting humans
	public int currResistance;
	public int baseAttackDamage;
	public float timeSinceLastAttack;
	public float speedPerSec;
	
	
	
	// 
	
	Vector3 LastTargetPosBack;
	public Vector3 LastTargetPos
	{
		set
		{
			TransOfTarget = null;
			LastTargetPosBack = value;
		}
		
		get
		{
			return LastTargetPosBack;
		}
	}
	
	
	
	Transform TransOfTargetBack;
	public Transform TransOfTarget 
	{
		set
		{
			if( TransOfTargetBack != null 
				&& value != null )
			{
				LastTargetPos = TransOfTargetBack.position;
				TransOfTargetBack = value;
			}
			else if( value != null )
			{
				LastTargetPos = value.position;
				TransOfTargetBack = value;
			}
		}
		
		get
		{
			return TransOfTargetBack;
		}
	}
	
	
	
	public Vector3 Position
	{
		get
		{
			return transform.position;
		}
	}
	
	// Use this for initialization
	public void Start() 
	{
		FastTex = (Texture2D)Resources.Load ("ZombieFastTex");
		SneakyTex = (Texture2D)Resources.Load ("ZombieSneakyTex");
		//ToughTex = (Texture2D)Resources.Load ("ZombieToughTex");
		HumanTex = (Texture2D)Resources.Load ("HumanTex");
		//MilitaryTex = (Texture2D)Resources.Load ("MilitaryTex");
		
		
		CurrUsingAttack = StateCharacterAtkUsing.WeakAttack;
		
		CurrBehavior = StateCharacterBehave.AtkNearest;
		
		//CurrCharacterType = StateCharacterType.Human;
		
		CurrZombType = StateZombieType.Fast;
		
		CurrAnimation = StateAnim.Standing;
		
		//isTargeting = false;
		
		isArmed = false;
		
		maxHealth = 8; // was 75;
		
		currHealth = maxHealth;
		
		maxResistance = 75;
		
		currResistance = maxResistance;
		
		baseAttackDamage = 2;
		
		timeSinceLastAttack = 0;
		
		speedPerSec = 1.5f;
		
		TransOfTargetBack = null;
		
		if( CurrCharacterType == StateCharacterType.Human )
		{
		
			
			HumanoidHandler.ListOfHumans.Add (this);
		}
		else
		{
		
			
			HumanoidHandler.ListOfZombies.Add(this);
		}
		
	
	}
	
	
	
	//TODO: remove test()
	void TestingFun()
	{
		
		
	}// TestingFun()
	
	
	
	
	
	// Update is called once per frame
	void Update () 
	{
	
		if( CurrCharacterType == StateCharacterType.Zombie)
		{
		
			if( isTargeting )
			{
				AnimateZombie();
			}
			else
			{
				// TODO: add function for handling AI according to UI
			}
		}
		else
		{
			AnimateHuman();
		}
		
		if( currHealth < 1 )
		{// remove self from the game
			if( CurrCharacterType == StateCharacterType.Human )
			{
				int thisID = transform.GetInstanceID();
				for( int i = 0; i < HumanoidHandler.ListOfHumans.Count; i++ )
				{
					if( thisID == HumanoidHandler.ListOfHumans[i].transform.GetInstanceID () )
					{
						HumanoidHandler.ListOfHumans.RemoveAt (i);
					}
				}
				// TODO: add random placement upon game over
				
				if( transform.position.y > 0.0f )
				{
					transform.Translate ( new Vector3( transform.position.x, -16.0f, transform.position.z)
					                  , Space.Self );
				}
			}
			else
			{
				int thisID = transform.GetInstanceID();
				for( int i = 0; i < HumanoidHandler.ListOfZombies.Count; i++ )
				{
					if( thisID == HumanoidHandler.ListOfZombies[i].transform.GetInstanceID () )
					{
						HumanoidHandler.ListOfZombies.RemoveAt (i);
					}
				}
			}
		}
	}// Update()
	
	
	
	
	
	void AnimateZombie()
	{//Debug.Log ("Entered animateZom()");
		
		
		
		
		if( CurrAnimation == StateAnim.Running )
		{//Check if target moved
		 //  --> get new target position
		 //Check if target reached 
		 //  --> switch to Attacking state
		 
			if( !animation.IsPlaying ("Run") )
			{
				animation.Play ("Run");
			}
			
			TranslateAndRotate ( 2 * speedPerSec);// set running speed & move
			
			if( TransOfTarget != null
				&& Vector3.Magnitude ( TransOfTarget.position - transform.position ) < .75f )
			{
			
				CurrAnimation = StateAnim.Attacking;
			
			}
		}
		else if( CurrAnimation == StateAnim.Walking )
		{//Check if target moved
		 //  --> get new target position
		 //Check if target reached 
		 //  --> switch to Attacking state
		
			if( !animation.IsPlaying ("Walk") )
			{
				animation.Play ("Walk");
			}
			
			TranslateAndRotate (speedPerSec);// set to walking speed & move
			
			if( TransOfTarget != null
				&& Vector3.Magnitude ( TransOfTarget.position - transform.position ) < .75f )
			{
			Debug.Log ("Set Attacking");
				CurrAnimation = StateAnim.Attacking;
			
			}
			
			
		}
		else if( CurrAnimation == StateAnim.Attacking )
		{//Check if target moved
		 //  --> get new target position
		 //      if too far switch to running
		 //else attack
			
			HumanoidHandler CurrTarg = null;
			
			if( !isArmed )
			{
			
			
				if( !animation.IsPlaying ("Hit") )
				{Debug.Log ("Entered Hit");
					animation.Play ("Hit");
				}
				
				CurrTarg = Attack();
			}// attack not armed
			else
			{
				
			}// attack armed
			
			if( CurrTarg != null
				&& CurrTarg.currHealth <= 0 )
			{
				CurrAnimation = StateAnim.Standing;
			}
			// zero speed -> zero translation
		}
		else // Character is Standing
		{// if (hunting)
		 //   find nearest
		 //   if (found)
		 //     -->running
		 // else play()
		 Debug.Log ("Entered Standing");
		 
		 
			if( CurrBehavior == StateCharacterBehave.AtkNearest 
				&& HumanoidHandler.ListOfHumans.Count > 0 )
			{// find nearest
				FindTarget ();
				CurrAnimation = StateAnim.Walking;				
				
			}
			else
			{Debug.Log ("Play Standing");
				animation.Play ("Standing");
				isTargeting = false;
			}
		}// body animation blocks
		
		
		
		
		if ( isArmed )
		{
			animation.Play ("HoldGun");
		}
		
		
	}// AnimateZombie()
	
	
	
	
	
	void AnimateHuman()
	{
		
	}// AnimateHuman()
	
	/// <summary>
	/// Attacks and returns current target or null if attack fails.
	/// </summary>
	HumanoidHandler Attack()
	{
		HumanoidHandler TargetHumanoid = null;
		if( HumanoidHandler.ListOfHumans.Count > 0 )
		{
			
			for( int i = 0; i < HumanoidHandler.ListOfHumans.Count; i++)
			{
				if( HumanoidHandler.ListOfHumans[i].transform.GetInstanceID ()
					== TransOfTarget.GetInstanceID () )
				{
					TargetHumanoid = HumanoidHandler.ListOfHumans[i];
				}
			}
			
			timeSinceLastAttack += Time.deltaTime;
			if( TargetHumanoid != null 
				&& timeSinceLastAttack > .5f )
			{
				TargetHumanoid.currHealth -= baseAttackDamage;
				timeSinceLastAttack = 0f;
						
			Debug.Log ("Entered Atk" + " health " + TargetHumanoid.currHealth);
					
			}
			
		}
		
		return TargetHumanoid;
	}
	
	
	
	/// <summary>
	/// Finds the nearest human.
	/// </summary>
	/// <returns>
	/// The nearest human.
	/// </returns>
	Transform FindNearestHuman()
	{
		if( HumanoidHandler.ListOfHumans.Count == 0 )
		{// this may be legit or not
			Debug.LogWarning ("Finding target when human list is empty");
			return null;
		}
		
		float minDist = 10000f;
		int index = -1;
		for(int i = 0; i < HumanoidHandler.ListOfHumans.Count; i++ )
		{
			if( Vector3.Magnitude ( 
				HumanoidHandler.ListOfHumans[i].transform.position
				 - transform.position )
				< minDist )
			{
				minDist = Vector3.Magnitude ( HumanoidHandler.ListOfHumans[i].transform.position
				                          - transform.position );
				index = i;
			}
			
		}
		
		return HumanoidHandler.ListOfHumans[index].transform;
	}// FindNearestHuman()
	
	
	
	/// <summary>
	/// Finds the target, the closest human.
	/// </summary>/
	void FindTarget()
	{
	
		
		
		Transform NewTarget = FindNearestHuman();
		
		// if transOfTarget equals null, lastTargetPos needs set
		// so set  twice
		//HACK: incorporate into the TransOfTarget property
		if( TransOfTarget == null ) 
		{
			TransOfTarget = NewTarget;
		}
		TransOfTarget = NewTarget;
		
	
	}// FindTarget()
	
	
	
	void TranslateAndRotate(float speed )
	{
		Vector3 tmpDir;
		
		
		if( TransOfTarget != null )
		{
			//TODO: Replace all uneeded references to the list
			tmpDir = (TransOfTarget.position -  transform.position).normalized;
		}
		else
		{
		Debug.LogWarning ("transOfTarget equals null in translate & rotate");
			return;
			//tmpDir =  Vector3.zero;
		}
		
		
		Vector2 tmpFwdXZ = new Vector2( transform.forward.x, transform.forward.z ).normalized;
		Vector2 tmpTargetXZ = new Vector2( tmpDir.x, tmpDir.z ).normalized;
		
		float angle = Vector2.Angle(  tmpFwdXZ, tmpTargetXZ );
		if( transform.InverseTransformPoint ( TransOfTarget.position ).z < -.0010 )
		{//HumanoidHandler.ListOfHumans[0].transform.position).z < -.10 )
			Debug.Log (" Added 180 ");
			angle += 180f;
		}
		
		transform.Rotate( new Vector3(0f, 1f, 0f ), angle * Time.deltaTime, Space.Self ); 
		
		float tmpX = (tmpDir * speed * Time.deltaTime ).x;
		float tmpY = (tmpDir * speed * Time.deltaTime ).y;
		float tmpZ = (tmpDir * speed * Time.deltaTime ).z;
		
		transform.Translate ( new Vector3( tmpX, 0f, tmpZ), Space.World );
		
		
		
	}// TranslateAndRotate()
}// class HumanoidHandler








 

